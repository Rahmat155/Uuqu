# TempMail MVP

Website temporary email sederhana berbahasa Indonesia. Frontend ini menggunakan Mail.tm API secara langsung untuk membuat akun sementara, mengambil inbox, membaca pesan, mendeteksi kemungkinan OTP, serta menghapus akun ketika timer lokal 15 menit habis.

## Penting sebelum dipublikasikan

- Ini adalah MVP/demo publik, bukan layanan email mandiri.
- Email menggunakan domain milik Mail.tm, bukan domain milik Anda.
- Mail.tm menyediakan API gratis tanpa API key, tetapi layanan dan domainnya dapat berubah, membatasi penggunaan, atau memblokir pendaftaran dari situs tertentu.
- Tautan atribusi ke Mail.tm disertakan sesuai ketentuan dokumentasi API. Periksa ketentuan terbaru sebelum deploy atau penggunaan publik.
- Timer 15 menit berjalan di browser. Penghapusan akun dicoba melalui API saat timer habis; jika browser ditutup, perangkat offline, atau API menolak, penghapusan tidak dijamin.
- Jangan gunakan untuk akun penting, perbankan, reset password, atau data sensitif. Jangan menyimpan token/kredensial email di localStorage.
- Pendeteksi OTP hanya heuristik angka 4–8 digit; selalu periksa isi pesan untuk memastikan kodenya benar.
- API pihak ketiga dapat mengubah CORS, rate limits, domain, dan perilaku kapan saja.

## Jalankan lokal

Cukup buka `index.html` di browser modern. Jika browser membatasi permintaan API dari `file://`, jalankan server lokal:

```bash
python -m http.server 8000
```

Lalu buka `http://localhost:8000`.

## Deploy gratis dengan GitHub Pages

1. Buat akun GitHub jika belum punya.
2. Buat repository baru bernama `tempmail` (Public).
3. Upload `index.html` ke root repository.
4. Buka **Settings → Pages**.
5. Pada **Build and deployment**, pilih **Deploy from a branch**.
6. Pilih branch `main`, folder `/ (root)`, lalu **Save**.
7. Tunggu proses selesai. URL biasanya berbentuk `https://USERNAME.github.io/tempmail/`.

Alternatif: unggah folder ini ke Cloudflare Pages lewat dashboard. Untuk frontend statis ini, tidak perlu backend sendiri selama API Mail.tm tetap bisa diakses langsung dari browser.

## Apakah perlu backend dan domain?

### Untuk MVP ini
- **Backend sendiri:** tidak wajib; browser berbicara langsung ke API Mail.tm.
- **Domain website:** tidak wajib; GitHub Pages menyediakan subdomain gratis.
- **Domain email sendiri:** tidak tersedia pada versi ini karena alamat memakai domain Mail.tm.

### Untuk layanan produksi dengan domain email sendiri
Anda perlu:
1. Membeli domain dan mengatur DNS/MX untuk menerima email.
2. Memilih provider yang benar-benar mendukung inbound email dan akses isi pesan melalui API/webhook.
3. Menjalankan backend untuk menerima pesan, membuat alias/alamat, mengelola masa aktif, dan membatasi penyalahgunaan.
4. Menyimpan token dan data pesan dengan aman, menambahkan rate limiting, abuse reporting, pemfilteran lampiran berbahaya, kebijakan privasi, dan proses penghapusan data.
5. Menguji deliverability, spam filtering, dan kompatibilitas pengirim. Tidak semua layanan akan mengirim ke alamat disposable.

Cloudflare Email Routing/Workers dapat menjadi bagian dari arsitektur custom-domain, tetapi sekadar membuat DNS atau halaman website tidak otomatis menyediakan inbox yang bisa dibaca. Perlu kode penerima email dan penyimpanan/pengambilan pesan.

## Fitur yang tersedia
- Membuat alamat acak di domain Mail.tm yang tersedia.
- Refresh inbox otomatis setiap 10 detik.
- Membuka isi pesan teks.
- Deteksi kemungkinan OTP 4–8 digit.
- Salin alamat dan OTP.
- Timer 15 menit dan percobaan penghapusan akun.
- Layout responsif untuk ponsel.

## Jika gagal
- Coba lagi beberapa saat kemudian; domain/API publik bisa sedang membatasi permintaan.
- Coba jalankan melalui HTTP/HTTPS, bukan `file://`.
- Periksa Console browser untuk pesan CORS atau API.
- Jangan memasukkan kredensial penting ke website ini.
